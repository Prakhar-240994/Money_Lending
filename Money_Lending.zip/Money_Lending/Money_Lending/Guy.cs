﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Money_Lending
{
    class Guy
    {
        public string name; 
        public int cash;

        public Guy(string name, int cash)
        {
            this.name = name;
            this.cash = cash;
        }

        public int giveCash(int amount)
        {
            if (amount <= cash && amount > 0)
            {
                cash -= amount;
                return amount;
            }
            else
            {
                MessageBox.Show("I don't have enough cash to give you "+name+" says..", "Out of Money");
                return 0;
            }
        }

        public int receiveCash(int amount)
        {
            if (amount > 0)
            {
                cash += amount;
                return amount;
            }
            else
            {
                MessageBox.Show("I can't accept this amount (" + amount + ")" + name + " says..", "Inappropriate amount");
                return 0;
            }
        }
    }
}
