﻿namespace Money_Lending
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bobsCash = new System.Windows.Forms.Label();
            this.bankCash = new System.Windows.Forms.Label();
            this.bankGivesJoe = new System.Windows.Forms.Button();
            this.bobGivesBank = new System.Windows.Forms.Button();
            this.joesCash = new System.Windows.Forms.Label();
            this.joeGivesBob = new System.Windows.Forms.Button();
            this.bobGivesJoe = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bobsCash
            // 
            this.bobsCash.AutoSize = true;
            this.bobsCash.Location = new System.Drawing.Point(54, 72);
            this.bobsCash.Name = "bobsCash";
            this.bobsCash.Size = new System.Drawing.Size(35, 13);
            this.bobsCash.TabIndex = 2;
            this.bobsCash.Text = "label3";
            // 
            // bankCash
            // 
            this.bankCash.AutoSize = true;
            this.bankCash.Location = new System.Drawing.Point(54, 104);
            this.bankCash.Name = "bankCash";
            this.bankCash.Size = new System.Drawing.Size(35, 13);
            this.bankCash.TabIndex = 4;
            this.bankCash.Text = "label5";
            // 
            // bankGivesJoe
            // 
            this.bankGivesJoe.Location = new System.Drawing.Point(51, 141);
            this.bankGivesJoe.Name = "bankGivesJoe";
            this.bankGivesJoe.Size = new System.Drawing.Size(75, 46);
            this.bankGivesJoe.TabIndex = 6;
            this.bankGivesJoe.Text = "Give $10 to Joe";
            this.bankGivesJoe.UseVisualStyleBackColor = true;
            this.bankGivesJoe.Click += new System.EventHandler(this.button1_Click);
            // 
            // bobGivesBank
            // 
            this.bobGivesBank.Location = new System.Drawing.Point(146, 140);
            this.bobGivesBank.Name = "bobGivesBank";
            this.bobGivesBank.Size = new System.Drawing.Size(75, 46);
            this.bobGivesBank.TabIndex = 7;
            this.bobGivesBank.Text = "Receive $5 from Bob";
            this.bobGivesBank.UseVisualStyleBackColor = true;
            this.bobGivesBank.Click += new System.EventHandler(this.button2_Click);
            // 
            // joesCash
            // 
            this.joesCash.AutoSize = true;
            this.joesCash.Location = new System.Drawing.Point(54, 38);
            this.joesCash.Name = "joesCash";
            this.joesCash.Size = new System.Drawing.Size(35, 13);
            this.joesCash.TabIndex = 8;
            this.joesCash.Text = "label1";
            // 
            // joeGivesBob
            // 
            this.joeGivesBob.Location = new System.Drawing.Point(51, 196);
            this.joeGivesBob.Name = "joeGivesBob";
            this.joeGivesBob.Size = new System.Drawing.Size(75, 46);
            this.joeGivesBob.TabIndex = 9;
            this.joeGivesBob.Text = "Joe gives $10 to Bob";
            this.joeGivesBob.UseVisualStyleBackColor = true;
            this.joeGivesBob.Click += new System.EventHandler(this.button3_Click);
            // 
            // bobGivesJoe
            // 
            this.bobGivesJoe.Location = new System.Drawing.Point(146, 196);
            this.bobGivesJoe.Name = "bobGivesJoe";
            this.bobGivesJoe.Size = new System.Drawing.Size(75, 46);
            this.bobGivesJoe.TabIndex = 10;
            this.bobGivesJoe.Text = "Bob gives $5 to Joe";
            this.bobGivesJoe.UseVisualStyleBackColor = true;
            this.bobGivesJoe.Click += new System.EventHandler(this.button4_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(275, 264);
            this.Controls.Add(this.bobGivesJoe);
            this.Controls.Add(this.joeGivesBob);
            this.Controls.Add(this.joesCash);
            this.Controls.Add(this.bobGivesBank);
            this.Controls.Add(this.bankGivesJoe);
            this.Controls.Add(this.bankCash);
            this.Controls.Add(this.bobsCash);
            this.Name = "Form1";
            this.Text = "Money_Lending";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label bobsCash;
        private System.Windows.Forms.Label bankCash;
        private System.Windows.Forms.Button bankGivesJoe;
        private System.Windows.Forms.Button bobGivesBank;
        private System.Windows.Forms.Label joesCash;
        private System.Windows.Forms.Button joeGivesBob;
        private System.Windows.Forms.Button bobGivesJoe;
    }
}

