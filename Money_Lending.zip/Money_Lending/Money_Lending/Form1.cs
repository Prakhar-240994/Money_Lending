﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Money_Lending
{
    public partial class Form1 : Form
    {
        Guy joe;
        Guy bob;
        int bank;

        
        public Form1()
        {
            InitializeComponent();
            joe = new Guy("Joe", 50);
            bob = new Guy("Bob", 100);
            bank = 100;

            UpdateForm();
        }

        public void UpdateForm()
        {
            joesCash.Text = joe.name + " has $ " + joe.cash;
            bobsCash.Text = bob.name + " has $ " + bob.cash;
            bankCash.Text = "Bank has $ " + bank;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            if (bank >= 10)
            {
                bank -= joe.receiveCash(10);
                UpdateForm();
            }
            else
            {
                MessageBox.Show("Bank is out of money");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (bob.cash >= 5)
            {
                bank += bob.giveCash(5);
                UpdateForm();
            }
            else
            {
                MessageBox.Show("Bob is out of money");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            bob.receiveCash(joe.giveCash(10));
            UpdateForm();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            joe.receiveCash(bob.giveCash(5));
            UpdateForm();
        }
    }
}
